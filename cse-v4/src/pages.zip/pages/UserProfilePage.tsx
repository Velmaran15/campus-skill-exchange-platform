import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User, Mail, Lock, Star, BookOpen, Clock, Plus, Shield,
  TrendingUp, Edit3, Check, X, Trash2, AlertTriangle, Eye, EyeOff,
} from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { skillsApi, sessionsApi, authApi } from '../api/services';
import type { Skill, Session } from '../types';
import { Avatar, Badge, StarRating, Spinner, Empty } from '../components/common';
import { Button } from '../components/common/Button';
import { AddSkillModal } from '../components/tutor/AddSkillModal';
import { levelColor, statusColor, formatDate } from '../utils/helpers';

// ─── Small inline edit field ──────────────────────────────────────────────────
interface EditFieldProps {
  label: string;
  value: string;
  onSave: (val: string) => Promise<void>;
  icon: React.ReactNode;
  type?: string;
}
const EditField: React.FC<EditFieldProps> = ({ label, value, onSave, icon, type = 'text' }) => {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const handleSave = async () => {
    if (!draft.trim() || draft === value) { setEditing(false); return; }
    setSaving(true); setErr('');
    try {
      await onSave(draft.trim());
      setEditing(false);
    } catch (e: unknown) {
      const msg = (e as { response?: { data?: { message?: string } } })?.response?.data?.message;
      setErr(msg ?? 'Failed to save.');
    } finally { setSaving(false); }
  };

  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs text-ink-400 font-body">{label}</label>
      {editing ? (
        <div className="flex flex-col gap-1">
          <div className="flex gap-2">
            <input
              type={type}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSave()}
              autoFocus
              className="flex-1 bg-white border border-ink-300 rounded-xl px-4 py-2.5 text-sm font-body text-ink-900 focus:outline-none focus:border-ink-900 focus:ring-2 focus:ring-ink-900/10 transition-all"
            />
            <button
              onClick={handleSave}
              disabled={saving}
              className="w-9 h-9 flex items-center justify-center bg-jade text-white rounded-xl hover:bg-jade-dark transition-colors disabled:opacity-50 cursor-pointer flex-shrink-0"
            >
              {saving ? <div className="w-3.5 h-3.5 border border-white border-t-transparent rounded-full animate-spin" /> : <Check size={15} />}
            </button>
            <button
              onClick={() => { setEditing(false); setDraft(value); setErr(''); }}
              className="w-9 h-9 flex items-center justify-center bg-ink-100 text-ink-500 rounded-xl hover:bg-ink-200 transition-colors cursor-pointer flex-shrink-0"
            >
              <X size={15} />
            </button>
          </div>
          {err && <p className="text-xs text-coral font-body">{err}</p>}
        </div>
      ) : (
        <div
          onClick={() => { setEditing(true); setDraft(value); }}
          className="group flex items-center gap-2 bg-ink-50 border border-transparent hover:border-ink-200 rounded-xl px-4 py-2.5 cursor-pointer transition-all"
          title={`Click to edit ${label}`}
        >
          <span className="text-ink-300">{icon}</span>
          <span className="flex-1 text-sm font-body text-ink-700">{value}</span>
          <Edit3 size={13} className="text-ink-300 opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
      )}
    </div>
  );
};

// ─── Change Password section ──────────────────────────────────────────────────
const ChangePassword: React.FC<{ onSuccess: () => void }> = ({ onSuccess }) => {
  const [open, setOpen] = useState(false);
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNext, setShowNext] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const handleSave = async () => {
    if (!current || !next) { setErr('All fields are required.'); return; }
    if (next.length < 6) { setErr('New password must be at least 6 characters.'); return; }
    if (next !== confirm) { setErr('Passwords do not match.'); return; }
    setSaving(true); setErr('');
    try {
      await authApi.updateProfile({ currentPassword: current, newPassword: next });
      setCurrent(''); setNext(''); setConfirm('');
      setOpen(false);
      onSuccess();
    } catch (e: unknown) {
      const msg = (e as { response?: { data?: { message?: string } } })?.response?.data?.message;
      setErr(msg ?? 'Failed to change password.');
    } finally { setSaving(false); }
  };

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 text-sm font-body text-ink-600 hover:text-ink-900 border border-ink-200 hover:border-ink-400 rounded-xl px-4 py-2.5 transition-all cursor-pointer w-full"
      >
        <Lock size={14} className="text-ink-400" />
        Change Password
        <Edit3 size={12} className="ml-auto text-ink-300" />
      </button>
    );
  }

  return (
    <div className="flex flex-col gap-3 bg-ink-50 rounded-2xl p-4 border border-ink-200">
      <p className="text-sm font-display font-semibold text-ink-900">Change Password</p>
      <div className="relative">
        <input
          type={showCurrent ? 'text' : 'password'}
          placeholder="Current password"
          value={current}
          onChange={(e) => setCurrent(e.target.value)}
          className="w-full bg-white border border-ink-200 rounded-xl px-4 py-2.5 pr-10 text-sm font-body text-ink-900 focus:outline-none focus:border-ink-900 focus:ring-2 focus:ring-ink-900/10 transition-all"
        />
        <button onClick={() => setShowCurrent(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-300 hover:text-ink-600 cursor-pointer">
          {showCurrent ? <EyeOff size={15} /> : <Eye size={15} />}
        </button>
      </div>
      <div className="relative">
        <input
          type={showNext ? 'text' : 'password'}
          placeholder="New password (min. 6 chars)"
          value={next}
          onChange={(e) => setNext(e.target.value)}
          className="w-full bg-white border border-ink-200 rounded-xl px-4 py-2.5 pr-10 text-sm font-body text-ink-900 focus:outline-none focus:border-ink-900 focus:ring-2 focus:ring-ink-900/10 transition-all"
        />
        <button onClick={() => setShowNext(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-300 hover:text-ink-600 cursor-pointer">
          {showNext ? <EyeOff size={15} /> : <Eye size={15} />}
        </button>
      </div>
      <input
        type="password"
        placeholder="Confirm new password"
        value={confirm}
        onChange={(e) => setConfirm(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && handleSave()}
        className="w-full bg-white border border-ink-200 rounded-xl px-4 py-2.5 text-sm font-body text-ink-900 focus:outline-none focus:border-ink-900 focus:ring-2 focus:ring-ink-900/10 transition-all"
      />
      {err && <p className="text-xs text-coral font-body">{err}</p>}
      <div className="flex gap-2">
        <Button variant="ghost" size="sm" onClick={() => { setOpen(false); setErr(''); }} fullWidth>Cancel</Button>
        <Button variant="primary" size="sm" onClick={handleSave} loading={saving} fullWidth>Update Password</Button>
      </div>
    </div>
  );
};

// ─── Delete Account modal ─────────────────────────────────────────────────────
const DeleteAccountModal: React.FC<{ onClose: () => void; onConfirm: () => Promise<void> }> = ({ onClose, onConfirm }) => {
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  const handle = async () => {
    if (confirm !== 'DELETE') { setErr('Type DELETE to confirm.'); return; }
    setLoading(true);
    try { await onConfirm(); } catch (e: unknown) {
      const msg = (e as { response?: { data?: { message?: string } } })?.response?.data?.message;
      setErr(msg ?? 'Failed to delete account.'); setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-900/60 backdrop-blur-sm p-4 animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm p-7 animate-fade-up">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-coral-light flex items-center justify-center flex-shrink-0">
            <AlertTriangle size={18} className="text-coral" />
          </div>
          <div>
            <h2 className="font-display font-bold text-ink-900 text-lg">Delete Account</h2>
            <p className="text-xs text-ink-400 font-body">This cannot be undone.</p>
          </div>
        </div>
        <p className="text-sm text-ink-500 font-body mb-4 leading-relaxed">
          All your data — skills, sessions, and reviews — will be permanently deleted.
          Type <strong className="text-coral font-mono">DELETE</strong> to confirm.
        </p>
        <input
          type="text"
          placeholder="Type DELETE"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          className="w-full bg-ink-50 border border-ink-200 rounded-xl px-4 py-2.5 text-sm font-mono text-ink-900 focus:outline-none focus:border-coral focus:ring-2 focus:ring-coral/10 transition-all mb-3"
        />
        {err && <p className="text-xs text-coral font-body mb-3">{err}</p>}
        <div className="flex gap-2">
          <Button variant="ghost" onClick={onClose} fullWidth>Cancel</Button>
          <Button variant="danger" onClick={handle} loading={loading} fullWidth>Delete Forever</Button>
        </div>
      </div>
    </div>
  );
};

// ─── Toast helper ─────────────────────────────────────────────────────────────
const useToast = () => {
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const show = useCallback((msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  }, []);
  return { toast, show };
};

// ─── Main Component ────────────────────────────────────────────────────────────
export const UserProfilePage: React.FC = () => {
  const { user, setAuth, logout } = useAuthStore();
  const navigate = useNavigate();
  const { toast, show } = useToast();

  const [skills, setSkills] = useState<Skill[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loadingData, setLoadingData] = useState(true);
  const [showAddSkill, setShowAddSkill] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [activeTab, setActiveTab] = useState<'skills' | 'sessions'>('skills');
  const [deletingSkill, setDeletingSkill] = useState<string | null>(null);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    fetchData();
  }, [user]);

  const fetchData = async () => {
    if (!user) return;
    setLoadingData(true);
    try {
      const promises: Promise<void>[] = [];

      if (user.role === 'tutor') {
        promises.push(
          skillsApi.getMySkills().then(r => setSkills(r.data)).catch(() => setSkills([])),
          sessionsApi.getTutorSessions().then(r => setSessions(r.data)).catch(() => setSessions([]))
        );
      } else {
        promises.push(
          sessionsApi.getLearnerSessions().then(r => setSessions(r.data)).catch(() => setSessions([]))
        );
      }
      await Promise.all(promises);
    } finally {
      setLoadingData(false);
    }
  };

  // Update name
  const handleNameUpdate = async (name: string) => {
    const res = await authApi.updateProfile({ name });
    // Update the user in Zustand store
    const token = localStorage.getItem('cse_token')!;
    setAuth(token, { ...user!, name: res.data.user?.name ?? name });
    show('Name updated successfully! ✅');
  };

  // Update email
  const handleEmailUpdate = async (email: string) => {
    const res = await authApi.updateProfile({ email });
    const token = localStorage.getItem('cse_token')!;
    setAuth(token, { ...user!, email: res.data.user?.email ?? email });
    show('Email updated successfully! ✅');
  };

  // Delete skill
  const handleDeleteSkill = async (skillId: string) => {
    setDeletingSkill(skillId);
    try {
      await skillsApi.deleteSkill(skillId);
      setSkills(prev => prev.filter(s => s._id !== skillId));
      show('Skill deleted.');
    } catch {
      show('Failed to delete skill.', 'error');
    } finally {
      setDeletingSkill(null);
    }
  };

  // Delete account
  const handleDeleteAccount = async () => {
    await authApi.deleteAccount();
    logout();
    navigate('/');
  };

  if (!user) return <Spinner />;

  const completedSessions = sessions.filter(s => s.status === 'completed').length;
  const pendingSessions = sessions.filter(s => s.status === 'pending').length;
  const acceptedSessions = sessions.filter(s => s.status === 'accepted').length;

  return (
    <div className="min-h-screen bg-ink-50">
      {/* Modals */}
      {showAddSkill && (
        <AddSkillModal
          onClose={() => setShowAddSkill(false)}
          onSuccess={() => { show('Skill added! 🎉'); fetchData(); }}
        />
      )}
      {showDelete && (
        <DeleteAccountModal
          onClose={() => setShowDelete(false)}
          onConfirm={handleDeleteAccount}
        />
      )}

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3 rounded-2xl shadow-xl font-body text-sm animate-fade-up ${
          toast.type === 'success' ? 'bg-jade text-white' : 'bg-coral text-white'
        }`}>
          {toast.msg}
        </div>
      )}

      {/* Hero */}
      <div className="bg-ink-900 text-white">
        <div className="max-w-4xl mx-auto px-4 py-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <div className="relative">
              <Avatar name={user.name} size="xl" className="!bg-amber !text-ink-900" />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-jade rounded-full border-2 border-ink-900" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                <h1 className="font-display font-bold text-3xl">{user.name}</h1>
                <span className={`text-xs font-body font-medium px-2.5 py-1 rounded-full capitalize ${
                  user.role === 'tutor' ? 'bg-amber text-ink-900' : 'bg-jade/20 text-jade border border-jade/30'
                }`}>
                  {user.role}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-white/50 text-sm font-body mb-4">
                <Mail size={13} /> {user.email}
              </div>
              <div className="flex items-center gap-5 flex-wrap">
                {user.role === 'tutor' && user.averageRating ? (
                  <div className="flex items-center gap-1.5">
                    <Star size={14} className="text-amber fill-amber" />
                    <span className="text-sm font-body text-white/80">{user.averageRating.toFixed(1)} rating</span>
                  </div>
                ) : null}
                <div className="flex items-center gap-1.5">
                  <TrendingUp size={14} className="text-jade" />
                  <span className="text-sm font-body text-white/80">{completedSessions} sessions completed</span>
                </div>
                {user.role === 'tutor' && (
                  <div className="flex items-center gap-1.5">
                    <BookOpen size={14} className="text-amber" />
                    <span className="text-sm font-body text-white/80">{skills.length} skill{skills.length !== 1 ? 's' : ''}</span>
                  </div>
                )}
              </div>
            </div>
            {user.role === 'tutor' && (
              <Button variant="secondary" onClick={() => setShowAddSkill(true)} className="flex-shrink-0">
                <Plus size={15} /> Add Skill
              </Button>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3 mt-8">
            <div className="bg-white/5 rounded-2xl p-4 text-center border border-white/10">
              <p className="font-display font-bold text-2xl text-white">{completedSessions}</p>
              <p className="text-xs font-body text-white/50 mt-0.5">Completed</p>
            </div>
            <div className="bg-white/5 rounded-2xl p-4 text-center border border-white/10">
              <p className="font-display font-bold text-2xl text-amber">{pendingSessions}</p>
              <p className="text-xs font-body text-white/50 mt-0.5">Pending</p>
            </div>
            <div className="bg-white/5 rounded-2xl p-4 text-center border border-white/10">
              <p className="font-display font-bold text-2xl text-jade">{acceptedSessions}</p>
              <p className="text-xs font-body text-white/50 mt-0.5">Accepted</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6 grid md:grid-cols-3 gap-6">

        {/* LEFT — tabs */}
        <div className="md:col-span-2 flex flex-col gap-5">
          {/* Tab buttons */}
          <div className="flex gap-2">
            {user.role === 'tutor' && (
              <button
                onClick={() => setActiveTab('skills')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-body font-medium transition-all cursor-pointer ${
                  activeTab === 'skills' ? 'bg-ink-900 text-white shadow-sm' : 'bg-white border border-ink-100 text-ink-500 hover:border-ink-300'
                }`}
              >
                <BookOpen size={14} /> My Skills
                {skills.length > 0 && (
                  <span className={`text-xs px-1.5 py-0.5 rounded-full ${activeTab === 'skills' ? 'bg-white/20' : 'bg-ink-100 text-ink-500'}`}>
                    {skills.length}
                  </span>
                )}
              </button>
            )}
            <button
              onClick={() => setActiveTab('sessions')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-body font-medium transition-all cursor-pointer ${
                activeTab === 'sessions' ? 'bg-ink-900 text-white shadow-sm' : 'bg-white border border-ink-100 text-ink-500 hover:border-ink-300'
              }`}
            >
              <Clock size={14} />
              {user.role === 'tutor' ? 'Session Requests' : 'My Sessions'}
              {sessions.length > 0 && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${activeTab === 'sessions' ? 'bg-white/20' : 'bg-ink-100 text-ink-500'}`}>
                  {sessions.length}
                </span>
              )}
            </button>
          </div>

          {/* Skills Tab */}
          {activeTab === 'skills' && user.role === 'tutor' && (
            loadingData ? <Spinner /> :
            skills.length === 0 ? (
              <Empty
                icon={<BookOpen size={40} />}
                title="No skills added yet"
                description="Share your expertise by adding your first skill"
                action={<Button variant="secondary" size="sm" onClick={() => setShowAddSkill(true)}><Plus size={14} /> Add Skill</Button>}
              />
            ) : (
              <div className="grid sm:grid-cols-2 gap-4">
                {skills.map(skill => (
                  <div key={skill._id} className="bg-white border border-ink-100 rounded-2xl p-5 hover:border-ink-200 transition-all group">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-display font-bold text-ink-900">{skill.name}</h3>
                      <div className="flex items-center gap-1.5">
                        <Badge className={levelColor(skill.level)}>{skill.level}</Badge>
                        <button
                          onClick={() => handleDeleteSkill(skill._id)}
                          disabled={deletingSkill === skill._id}
                          className="opacity-0 group-hover:opacity-100 w-7 h-7 flex items-center justify-center text-ink-300 hover:text-coral hover:bg-coral-light rounded-lg transition-all cursor-pointer"
                          title="Delete skill"
                        >
                          {deletingSkill === skill._id
                            ? <div className="w-3 h-3 border border-coral border-t-transparent rounded-full animate-spin" />
                            : <Trash2 size={13} />}
                        </button>
                      </div>
                    </div>
                    <p className="text-sm text-ink-500 font-body leading-relaxed line-clamp-3">{skill.description}</p>
                    {skill.averageRating !== undefined && skill.averageRating > 0 && (
                      <div className="flex items-center gap-2 mt-3 pt-3 border-t border-ink-50">
                        <StarRating value={skill.averageRating} size={13} />
                        <span className="text-xs text-ink-400 font-body">{skill.averageRating.toFixed(1)} · {skill.totalSessions ?? 0} sessions</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )
          )}

          {/* Sessions Tab */}
          {activeTab === 'sessions' && (
            loadingData ? <Spinner /> :
            sessions.length === 0 ? (
              <Empty
                icon={<Clock size={40} />}
                title="No sessions yet"
                description={user.role === 'learner' ? 'Request a session from any tutor to get started' : 'Sessions requested by learners will appear here'}
                action={user.role === 'learner' ? (
                  <Button variant="secondary" size="sm" onClick={() => navigate('/search')}>Explore Skills</Button>
                ) : undefined}
              />
            ) : (
              <div className="flex flex-col gap-3">
                {sessions.map(session => {
                  const other = user.role === 'tutor' ? session.learner : session.tutor;
                  return (
                    <div key={session._id} className="bg-white border border-ink-100 rounded-2xl p-5 flex items-center gap-4 hover:border-ink-200 transition-all">
                      <Avatar name={other?.name ?? '?'} size="md" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <p className="font-display font-semibold text-ink-900 text-sm truncate">{other?.name ?? 'Unknown'}</p>
                          <Badge className={statusColor(session.status)}>
                            {session.status.charAt(0).toUpperCase() + session.status.slice(1)}
                          </Badge>
                        </div>
                        <p className="text-xs text-ink-400 font-body truncate">{session.skill?.name} · {session.skill?.level}</p>
                        <p className="text-[10px] text-ink-300 font-body mt-0.5">{formatDate(session.createdAt)}</p>
                      </div>
                      {session.status === 'completed' && session.rating && (
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <Star size={13} className="text-amber fill-amber" />
                          <span className="text-xs font-body text-ink-600">{session.rating}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )
          )}
        </div>

        {/* RIGHT — account settings */}
        <div className="flex flex-col gap-4">
          <h3 className="font-display font-semibold text-ink-900 text-sm flex items-center gap-2">
            <Shield size={15} className="text-amber" /> Account Settings
          </h3>

          <div className="bg-white border border-ink-100 rounded-2xl p-5 flex flex-col gap-4">
            <EditField
              label="Full Name"
              value={user.name}
              onSave={handleNameUpdate}
              icon={<User size={14} />}
            />
            <EditField
              label="Email Address"
              value={user.email}
              onSave={handleEmailUpdate}
              icon={<Mail size={14} />}
              type="email"
            />
            <div className="flex items-center gap-2 bg-ink-50 rounded-xl px-4 py-2.5">
              <Shield size={14} className="text-ink-300" />
              <div className="flex-1">
                <p className="text-[10px] text-ink-400 font-body">Role</p>
                <p className="text-sm font-body text-ink-700 capitalize">{user.role}</p>
              </div>
            </div>

            <ChangePassword onSuccess={() => show('Password changed! 🔐')} />
          </div>

          {/* Danger zone */}
          <div className="bg-white border border-coral/20 rounded-2xl p-5">
            <p className="text-xs font-display font-semibold text-coral mb-3 uppercase tracking-wide">Danger Zone</p>
            <p className="text-xs text-ink-400 font-body mb-3 leading-relaxed">
              Permanently delete your account and all associated data. This action cannot be reversed.
            </p>
            <button
              onClick={() => setShowDelete(true)}
              className="w-full flex items-center justify-center gap-2 text-sm font-body font-medium text-coral border border-coral/30 hover:bg-coral hover:text-white rounded-xl px-4 py-2.5 transition-all cursor-pointer"
            >
              <Trash2 size={14} /> Delete My Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
